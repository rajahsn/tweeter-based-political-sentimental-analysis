﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

namespace ML_political_anlysis
{
    public partial class Party_wise_analysis : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_analaze_Click(object sender, EventArgs e)
        {

            String str_data = ddl_party.SelectedValue.ToString();
            String str_query = "SELECT count(*),analysis FROM ml_political.tweets_tbl where twetts like '%" + str_data + "%' group by analysis";
            fill_Data(str_query);
        }

        public static void ShowMessageBox(string _message)
        {
            System.Web.UI.Page page = HttpContext.Current.Handler as System.Web.UI.Page;
            page.ClientScript.RegisterStartupScript(typeof(System.Web.UI.Page), "key2", "<script>alert('" + _message + "');</script>");
        }

        protected void fill_Data(String str_query)
        {
            try
            {
                MySqlConnection Sql_Con = new MySqlConnection("server=localhost;User Id=root; password=root;database=ml_political");

                Sql_Con.Open();

                DataSet ds_tweets = new DataSet();


                MySqlDataAdapter dta = new MySqlDataAdapter(str_query, Sql_Con);
                dta.Fill(ds_tweets);

                Dictionary<String, int> testData = new Dictionary<String, int>();
                if (ds_tweets.Tables[0].Rows.Count > 0)
                {

                    for (int i = 0; i < ds_tweets.Tables[0].Rows.Count; i++)
                    {
                        String count = ds_tweets.Tables[0].Rows[i][0].ToString();
                        testData.Add(ds_tweets.Tables[0].Rows[i][1].ToString(), int.Parse(count));

                        Chart_stat.Series["Testing"].Points.DataBind(testData, "Key", "Value", String.Empty);
                    }
                }
                else
                {
                    ShowMessageBox("There is no tweet with the given filter");
                }

            }
            catch (Exception ex)
            {

            }
        }

        protected void btn_candidate_Click(object sender, EventArgs e)
        {
            String str_data = txt_candidate.Text;
            if (str_data == "")
            {
                ShowMessageBox("Please enter the Candidate to analyze");
                return;
            }
            String str_query = "SELECT count(*),analysis FROM ml_political.tweets_tbl where twetts like '%" + str_data + "%' group by analysis";
            fill_Data(str_query);
        }
    }
}