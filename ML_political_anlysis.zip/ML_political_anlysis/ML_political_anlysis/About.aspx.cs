﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Data;
using MySql.Data.MySqlClient;
using System.IO;
using System.Text;


namespace ML_political_anlysis
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            fill();
        }
        public static void ShowMessageBox(string _message)
        {
            System.Web.UI.Page page = HttpContext.Current.Handler as System.Web.UI.Page;
            page.ClientScript.RegisterStartupScript(typeof(System.Web.UI.Page), "key2", "<script>alert('" + _message + "');</script>");
        }

        protected void btn_Parse_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            if (xlApp == null)
            {
                ShowMessageBox("Excel is not properly installed!!");
                return;
            }

            String savePath = @"c:\in_data\";
            String fileName = FileUpload1.FileName;

            // Append the name of the file to upload to the path.
            savePath += fileName;


            FileUpload1.SaveAs(savePath);


            Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(savePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
        Type.Missing, Type.Missing, Type.Missing, Type.Missing,
        Type.Missing, Type.Missing, Type.Missing, Type.Missing,
        Type.Missing, Type.Missing);

            try
            {
                Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                object misValue = System.Reflection.Missing.Value;

                Range excelRange = xlWorkSheet.UsedRange;

                object[,] valueArray = (object[,])excelRange.get_Value(
                    XlRangeValueDataType.xlRangeValueDefault);

                System.Data.DataTable dt_Heart_data = new System.Data.DataTable();
                bool flag = false;

                int from_index = 0;

                for (int j = 2; j < xlWorkSheet.UsedRange.Rows.Count; j++)
                {


                    try
                    {
                        String str_name = "";
                        String str_tweet = "";
                        String str_tweet_result = "";
                        if (valueArray[j, 1] != null)
                        {
                            str_name = valueArray[j, 1].ToString();
                        }
                        if (valueArray[j, 2] != null)
                        {
                            str_tweet = valueArray[j, 2].ToString();
                            str_tweet = str_tweet.Replace("\'", "");
                        }
                        if (valueArray[j, 3] != null)
                        {
                            str_tweet_result = valueArray[j, 3].ToString();
                            
                        }
                        else
                        {
                            continue;
                        }


                        MySqlConnection Sql_Con = new MySqlConnection("server=localhost;User Id=root; password=root;database=ml_political");

                        Sql_Con.Open();

                        String str_insert = "insert into ml_political.tweets_tbl values(null,'" + str_tweet + "','" + str_name + "',now(),'" + str_tweet_result + "')";
                        MySqlCommand sql_cmd = new MySqlCommand(str_insert, Sql_Con);
                        sql_cmd.ExecuteNonQuery();
                        Sql_Con.Close();

                    }
                    catch (Exception ex)
                    {
                        ShowMessageBox(ex.Message);

                    }

                    fill();
                }

                ShowMessageBox("data read successfully");

            }
            catch (Exception ex)
            {
                ShowMessageBox(ex.Message);
                xlWorkBook.Close(false, Type.Missing, Type.Missing);
                Marshal.ReleaseComObject(xlWorkBook);

                xlApp.Quit();
                Marshal.FinalReleaseComObject(xlApp);
            }
        }
        

        protected void fill()
        {
            try
            {
                MySqlConnection Sql_Con = new MySqlConnection("server=localhost;User Id=root; password=root;database=ml_political");

                Sql_Con.Open();

                DataSet ds_tweets = new DataSet();


                MySqlDataAdapter dta = new MySqlDataAdapter("select twetts as tweets,  datetim as DateTime from ml_political.tweets_tbl ", Sql_Con);
                dta.Fill(ds_tweets);

                GridView_Data.DataSource = ds_tweets.Tables[0];
                GridView_Data.DataBind();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        protected void btn_delte_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection Sql_Con = new MySqlConnection("server=localhost;User Id=root; password=root;database=ml_political");

                Sql_Con.Open();

                String str_insert = "Delete from ml_political.tweets_tbl ";
                MySqlCommand sql_cmd = new MySqlCommand(str_insert, Sql_Con);
                if (sql_cmd.ExecuteNonQuery() > 0)
                {
                    ShowMessageBox("All records are deleted");
                    fill();
                }
                else
                {
                    ShowMessageBox("Error in Deleteion");
                }

                Sql_Con.Close();

            }
            catch (Exception ex)
            {

            }
        }
    }
}
